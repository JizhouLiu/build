#
# IBM Confidential
#
# OCO Source Materials
#
# NextGen Workbench
#
# (c) Copyright IBM Corp. 2016
#
# The source code for this program is not published or otherwise
# divested of its trade secrets, irrespective of what has been
# deposited with the U.S. Copyright Office.
#

from pyspark.mllib.common import inherit_doc

from spss.ml.common.wrapper import SPSSJavaWrapper


@inherit_doc
class DateTimeUtils(object):
    """
    Date time utils.
    """

    def __init__(self):
        super(DateTimeUtils, self).__init__()

    @staticmethod
    def toSeconds(year=1970, month=1, day=1, hour=0, minute=0, second=0):
        """
        Returns the number of seconds since January 1, 1970, 00:00:00 represented by specified date/time.

        :param year: the year
        :param month: the month of the year, from 1 to 12
        :param day: the day of the month, from 1 to 31
        :param hour: the hour of the day, from 0 to 23
        :param minute: the minute of the hour, from 0 to 59
        :param second: the second of the minute, from 0 to 59
        :return: the number of seconds since January 1, 1970, 00:00:00 represented by specified date/time
        """
        return SPSSJavaWrapper._new_java_obj("com.ibm.spss.ml.utils.DateTimeUtils").toSeconds(year, month, day, hour,
                                                                                              minute, second)
