#
# IBM Confidential
#
# OCO Source Materials
#
# NextGen Workbench
#
# (c) Copyright IBM Corp. 2016
#
# The source code for this program is not published or otherwise
# divested of its trade secrets, irrespective of what has been
# deposited with the U.S. Copyright Office.
#

from pyspark.mllib.common import inherit_doc

from spss.ml.common.wrapper import AFEstimator, DirectorScorer
from spss.ml.param.spatiotemporalprediction import SpatioTemporalPredictionParams
from spss.ml.param.spatiotemporalpredictionmodel import SpatioTemporalPredictionModelParams


@inherit_doc
class SpatioTemporalPrediction(AFEstimator, SpatioTemporalPredictionParams):
    """
    Spatio-temporal Prediction (STP) is a modeling tool that applies to regular
    spatio-temporal data with a fixed set of spatial locations (either point locations
    or center points of areas on a lattice) and a set of equally spaced time points.
    STP fits a linear model for measurements taken over time at locations in 2D/3D space
    and can issue predictions at any locations for future time. Furthermore, the model
    includes external predictors, so model-based what-if analysis can be performed.

    Example code:

    >>> from spss.ml.common.wrapper import LocalContainerManager
    >>> from spss.ml.spatiotemporal.spatiotemporalprediction import SpatioTemporalPrediction, SpatioTemporalPredictionModel
    >>> stp = SpatioTemporalPrediction().
    ...       setTargetField("demand").
    ...       setInputFieldList(["age"]).
    ...       setLocationFieldList(["longitude", "latitude"]).
    ...       setTimeIndexField("year").
    ...       setArLag(2).
    ...       setConfidenceLevel(50.0)
    >>> stpScore = stp.fit(data)
    >>> scored = stpScore.transform(data)
    >>> scored.show()
    """

    def __init__(self, manager=None):
        super(SpatioTemporalPrediction, self).__init__(manager,
                                                    'com.ibm.spss.ml.spatiotemporal.SpatioTemporalPrediction')

    def _create_model(self, java_model):
        return SpatioTemporalPredictionModel(None, java_model)


@inherit_doc
class SpatioTemporalPredictionModel(DirectorScorer, SpatioTemporalPredictionModelParams):
    """
    Model produced by :class:`SpatioTemporalPrediction`..

    SpatioTemporalPrediction exports two outputs:

    * StatXML.xml file.
    * STPXML.xml file.

    More details about outputs, please refer to
    `SpatioTemporalPrediction Output Document <../../../../../../output-doc/SpatioTemporalPrediction.html>`_.
    """

    def __init__(self, manager, java_model=None):
        super(SpatioTemporalPredictionModel, self).__init__(manager,
                                                         'com.ibm.spss.ml.spatiotemporal.SpatioTemporalPredictionModel',
                                                         java_model)
