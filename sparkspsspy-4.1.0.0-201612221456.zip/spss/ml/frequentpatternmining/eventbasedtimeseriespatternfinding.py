#
# IBM Confidential
#
# OCO Source Materials
#
# NextGen Workbench
#
# (c) Copyright IBM Corp. 2016
#
# The source code for this program is not published or otherwise
# divested of its trade secrets, irrespective of what has been
# deposited with the U.S. Copyright Office.
#

from pyspark.mllib.common import inherit_doc

from spss.ml.common.wrapper import OutputDataCapabilitiesEstimator, DirectorScorer, StatXMLExportable
from spss.ml.param.eventbasedtimeseriespatternfinding import EventBasedTimeSeriesPatternFindingParams
from spss.ml.param.eventbasedtimeseriespatternfindingmodel import EventBasedTimeSeriesPatternFindingModelParams


@inherit_doc
class EventBasedTimeSeriesPatternFinding(OutputDataCapabilitiesEstimator, EventBasedTimeSeriesPatternFindingParams):
    """
    Event-Based Time Series (EBTS) data consists of sequences of events that occurred at different time points from multiple entities. For a sequence of events for each entity, different event types might be included; each event might be related to a numeric value; and the time spaces between adjacent events are of arbitrary length.
    The EBTS framework includes pre-processing of raw data to the required format, discretization of event values and time duration between events, and temporal pattern mining of discovering sequential association rules. The applications of the result rules include next possible event prediction with a value category and   entity clustering/segmentation.

    Example code:

    >>> from spss.ml.frequentpatternmining.eventbasedtimeseriespatternfinding import EventBasedTimeSeriesPatternFinding
    >>> from spss.ml.frequentpatternmining.eventbasedtimeseriespatternfinding import EventBasedTimeSeriesPatternFindingModel
    >>> ebts = EventBasedTimeSeriesPatternFinding().
    ...     setEntityIDField("ID").
    ...     setEventTimeField("Time").
    ...     setEventTypeField("EventType").
    ...     setEventValueField("Value")
    >>> model = ebts.fit(df)
    >>> odf = ebts.outputData(self.sqlContext)
    """

    def __init__(self, manager=None):
        super(EventBasedTimeSeriesPatternFinding, self).__init__(manager,
                                                                 'com.ibm.spss.ml.frequentpatternmining.EventBasedTimeSeriesPatternFinding')

    def _create_model(self, java_model):
        return EventBasedTimeSeriesPatternFindingModel(None, java_model)


@inherit_doc
class EventBasedTimeSeriesPatternFindingModel(DirectorScorer, EventBasedTimeSeriesPatternFindingModelParams, StatXMLExportable):
    """
    Model produced by :class:`EventBasedTimeSeriesPatternFinding`.

    EventBasedTimeSeriesPatternFinding exports two outputs:

    * PatternXML file, contains model information.
    * StatXML file, contains model information.

    More details about outputs, please refer to
    `EventBasedTimeSeriesPatternFinding Output Document <../../../../../output-doc/EventBasedTimeSeriesPatternFinding.html>`_.
    """

    def __init__(self, manager, java_model=None):
        super(EventBasedTimeSeriesPatternFindingModel, self).__init__(manager,
                                                                      'com.ibm.spss.ml.frequentpatternmining.EventBasedTimeSeriesPatternFindingModel',
                                                                      java_model)

    def patternXML(self):
        """
        Extract PatternXML to string.
        """
        return self._java_obj.patternXML()
