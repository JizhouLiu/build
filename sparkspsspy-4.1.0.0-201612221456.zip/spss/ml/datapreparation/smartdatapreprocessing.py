#
# IBM Confidential
#
# OCO Source Materials
#
# NextGen Workbench
#
# (c) Copyright IBM Corp. 2016
#
# The source code for this program is not published or otherwise
# divested of its trade secrets, irrespective of what has been
# deposited with the U.S. Copyright Office.
#

from pyspark.mllib.common import inherit_doc

from spss.ml.common.wrapper import AFTransformer, AFEstimator, IdentityScorer, ContainerCapability, StatJSONExportable
from spss.ml.param.smartdatapreprocessingrelevanceanalysis import SmartDataPreprocessingRelevanceAnalysisParams
from spss.ml.param.smartdatapreprocessingrelevanceredundancyanalysis import SmartDataPreprocessingRelevanceRedundancyAnalysisParams


@inherit_doc
class SmartDataPreprocessingRelevanceAnalysis(AFTransformer, ContainerCapability, SmartDataPreprocessingRelevanceAnalysisParams, StatJSONExportable):
    """
    Smart Data Preprocessing (SDP) engine is a new analytic component for data preparation. It consists of three separate modules: relevance analysis, relevance and redundancy analysis, and smart metadata (SMD) integration.

    Given the data with regular fields, list fields, and map fields, relevance analysis evaluates the associations of input fields with targets, and selects a specified number of fields for subsequent analysis. Meanwhile, it expands list fields and map fields, and extracts the selected fields into regular column-based format.

    Due to the efficiency of relevance analysis, it is also used to reduce the large number of fields in wide data to a moderate level where traditional analytics can work.

    SmartDataPreprocessingRelevanceAnalysis exports outputs: - JSON file, contain model information - a new column-based data - the related data model

    More details about outputs, please refer to `SmartDataPreprocessing Output Document <../../../../../../output-doc/SmartDataPreprocessing.html>`_.

    Example code:\n
    >>> from spss.ml.datapreparation.smartdatapreprocessing import SmartDataPreprocessingRelevanceAnalysis
    >>> sdpRA = SmartDataPreprocessingRelevanceAnalysis().
    ...     setInputFieldList(["holderage", "vehicleage", "claimamt"]).
    ...     setTargetFieldList(["vehiclegroup", "nclaims"]).
    ...     setMaxNumTarget(3).
    ...     setInvalidPairsThresEnabled(True).
    ...     setRMSSEThresEnabled(True).
    ...     setAbsVariCoefThresEnabled(True).
    ...     setInvalidPairsThreshold(0.7).
    ...     setRMSSEThreshold(0.7).
    ...     setAbsVariCoefThreshold(0.05).
    ...     setMaxNumSelFields(2).
    ...     setConCatRatio(0.3).
    ...     setFilterSelFields(True)
    >>> predictions = sdpRA.transform(data)
    >>> predictions.show()
    """

    def __init__(self, manager=None):
        super(SmartDataPreprocessingRelevanceAnalysis, self).__init__(manager,
                                                                      'com.ibm.spss.ml.datapreparation.SmartDataPreprocessingRelevanceAnalysis')


@inherit_doc
class SmartDataPreprocessingRelevanceRedundancyAnalysis(AFEstimator, SmartDataPreprocessingRelevanceRedundancyAnalysisParams):
    """
    Relevance and redundancy analysis is performed on data with a small or moderate number of regular fields.

    Relevance and redundancy analysis ranks fields according to both relevance and redundancy, and it selects proper fields for predictive analysis. Moreover, it selects field pairs for bivariate analysis and detects redundancy insights that enable users to have more comprehensive understanding of their data.

    Example code:\n
    >>> from spss.ml.datapreparation.smartdatapreprocessing import SmartDataPreprocessingRelevanceAnalysis
    >>> from spss.ml.common.wrapper import LocalContainerManager
    >>> local = LocalContainerManager()
    >>> local.exportContainers("StatXML", con)
    >>> sdpRRA = SmartDataPreprocessingRelevanceRedundancyAnalysis(local).
    ...     setInputContainerKeys(["StatXML"])).
    ...     setInputFieldList(["SAS_1", "SAF_1", "STC_1", "wool_1", "wool_3", "wool_4", "wool_5", "wool_6", "wool_7", "wool_8"]).
    ...     setTargetFieldList(["airpass"]).
    ...     setMaxNumTarget(5).
    ...     setInvalidPairsThresEnabled(True).
    ...     setRMSSEThresEnabled(True).
    ...     setAbsVariCoefThresEnabled(True).
    ...     setInvalidPairsThreshold(0.7).
    ...     setRMSSEThreshold(0.7).
    ...     setAbsVariCoefThreshold(0.05).
    ...     setMaxNumModelingFields(2000).
    ...     setRelevanceWeight(0.6).
    ...     setLimitTotalModelingFields(True).
    ...     setMaxNumTotalModelingFields(2000).
    ...     setMaxNumRelevantFields(1000).
    ...     setLimitTotalExplorationFields(True).
    ...     setMaxNumTotalExplorationFields(1000).
    ...     setMaxNumFieldPairs(2000).
    ...     setRedundancyThreshold(0.7).
    ...     setSigLevel(0.05)
    >>> sdpRRAModel = sdpRRA.fit(data)
    >>> predictions = sdpRRAModel.transform(data)
    >>> predictions.show()
    """

    def __init__(self, manager=None):
        super(SmartDataPreprocessingRelevanceRedundancyAnalysis, self).__init__(manager,'com.ibm.spss.ml.datapreparation.SmartDataPreprocessingRelevanceRedundancyAnalysis')

    def _create_model(self, java_model):
        return SmartDataPreprocessingRelevanceRedundancyAnalysisModel(None, java_model)


@inherit_doc
class SmartDataPreprocessingRelevanceRedundancyAnalysisModel(IdentityScorer, StatJSONExportable):
    """
    Model produced by :class:`SmartDataPreprocessingRelevanceRedundancyAnalysis`.

    SmartDataPreprocessingRelevanceRedundancyAnalysis exports outputs:

    * JSON file, contain model information.

    More details about outputs, please refer to `SmartDataPreprocessing Output Document <../../../../../../output-doc/SmartDataPreprocessing.html>`_.
    """

    def __init__(self, manager, java_model=None):
        super(SmartDataPreprocessingRelevanceRedundancyAnalysisModel, self).__init__(manager, 'com.ibm.spss.ml.datapreparation.SmartDataPreprocessingRelevanceRedundancyAnalysisModel', java_model)
