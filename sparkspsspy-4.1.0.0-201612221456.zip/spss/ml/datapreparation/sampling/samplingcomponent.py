#
# IBM Confidential
#
# OCO Source Materials
#
# NextGen Workbench
#
# (c) Copyright IBM Corp. 2016
#
# The source code for this program is not published or otherwise
# divested of its trade secrets, irrespective of what has been
# deposited with the U.S. Copyright Office.
#

from pyspark.mllib.common import inherit_doc

from spss.ml.common.wrapper import JavaTransformer
from spss.ml.param.samplingmodel import SamplingModelParams

@inherit_doc
class SamplingModel(JavaTransformer, SamplingModelParams):
    """
    The samplingModel function selects a pseudo-random percentage of the subsequence of input records defined by every Nth record for a given step size N. The total sample size may be optionally limited by a maximum.

    When the step size is 1, the subsequence is the entire sequence of input records. When the sampling ratio is 1.0, selection becomes deterministic, not pseudo-random.

    Note that with distributed data, the samplingModel function applies the selection criteria independently to each data split. The maximum sample size, if any, applies independently to each split and not to the entire data source; the subsequence is started afresh at the start of each split.

    Example code: \n
    >>> from spss.ml.datapreparation.sampling.samplingcomponent import SamplingModel
    >>> transformer = SamplingModel().setSamplingRatio(1.0).setSamplingStep(2).setRandomSeed(123).setDiscard(False)
    >>> sampled = transformer.transform(unionDF)
    """
    def __init__(self):
        super(SamplingModel, self).__init__()
        self._java_obj = self._new_java_obj('com.ibm.spss.ml.datapreparation.sampling.SamplingModel',
                                            self.uid)

class SequentialSampling(SamplingModel):
    """
    The sequentialSampling function is similar to the samplingModel function. It also selects a pseudo-random percentage of the subsequence of input records defined by every Nth record for a given step size N. The total sample size may be optionally limited by a maximum.

    When the step size is 1, the subsequence is the entire sequence of input records. When the sampling ratio is 1.0, selection becomes deterministic, not pseudo-random. The main difference between sequentialSampling and samplingModel is that with distributed data, the sequentialSampling function applies the selection criteria to the entire data source, while the samplingModel function applies the selection criteria independently to each data split.

    Example code:\n
    >>> from spss.ml.datapreparation.sampling.samplingcomponent import SequentialSampling
    >>> transformer = SequentialSampling().setSamplingRatio(1.0).setSamplingStep(2).setRandomSeed(123).setDiscard(False)
    >>> sampled = transformer.transform(unionDF)
    """
    def __init__(self):
        super(SequentialSampling, self).__init__()
        self._java_obj = self._new_java_obj('com.ibm.spss.ml.datapreparation.sampling.SequentialSampling',
                                            self.uid)
