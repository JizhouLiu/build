#
# IBM Confidential
#
# OCO Source Materials
#
# NextGen Workbench
#
# (c) Copyright IBM Corp. 2016
#
# The source code for this program is not published or otherwise
# divested of its trade secrets, irrespective of what has been
# deposited with the U.S. Copyright Office.
#

from pyspark.mllib.common import inherit_doc

from spss.ml.common.wrapper import AFEstimator, Scorer
from spss.ml.param.hascommonparams import HasCommonParamsParams
from spss.ml.param.hasfreqfield import HasFreqFieldParams
from spss.ml.param.hasregressionparams import HasRegressionParamsParams
from spss.ml.param.linearregression import LinearRegressionParams
from spss.ml.param.hastargetfield import HasTargetFieldParams
from spss.ml.param.hasinputfieldlist import HasInputFieldListParams
from spss.ml.param.haspredictioncol import HasPredictionColParams


@inherit_doc
class LinearRegression(AFEstimator, LinearRegressionParams, HasTargetFieldParams, HasInputFieldListParams,
                       HasFreqFieldParams):
    """
    The linear regression model analyzes the predictive relationship between a continuous target and one or more predictors which can be continuous or categorical.

    Features of the linear regression model include automatic interaction effect detection, forward stepwise model selection,
    diagnostic checking, and unusual category detection based on  `EMMEAN Estimated Marginal Means` (EMMEANS).

    Example code1:

    >>> from spss.ml.classificationandregression.linearregression import LinearRegression
    >>> le = LinearRegression().
    ...     setTargetField("class").
    ...     setInputFieldList(["motor", "screw", "pgain"]).
    ...     setRegrWeightField("vgain").
    ...     setDetectTwoWayInteraction(False).
    ...     setVarSelectionMethod("forwardStepwise").
    ...     setCriteria4ForwardStepwise("AICC")
    >>> model = le.fit(df)
    >>> score = model.transform(df)
    >>> d = score.take(2)
    >>> containers = model.containerSeq()

    Below is one case including LE Regularization
    Example code2:

    >>> from spss.ml.classificationandregression.linearregression import LinearRegression
    >>> le = LinearRegression().setTargetField("target").
    ...     setVarSelectionMethod("elasticNet").
    ...     setInputFieldList(Array("predictor1", "predictor2", "predictorn")).
    ...     setDetectTwoWayInteraction(False).
    ...     setUserSpecPenaltyParams(True).
    ...     setParamLambda1(1.0).
    ...     setParamLambda2(1.0)
    >>> model = le.fit(df)
    >>> score = model.transform(df)
    >>> d = score.take(2)
    >>> containers = model.containerSeq()
    """

    def __init__(self, manager=None):
        super(LinearRegression, self).__init__(
            manager,
            'com.ibm.spss.ml.classificationandregression.LinearRegression')

    def _create_model(self, java_model):
        return LinearRegressionModel(None, java_model)


@inherit_doc
class LinearRegressionModel(Scorer,
                            HasCommonParamsParams,
                            HasRegressionParamsParams,
                            HasPredictionColParams):
    """
    Model produced by :class:`LinearRegression`.

    LinearRegression exports two outputs:

    * PMML file, contains model that follows `DMG PMML Standard <http://dmg.org/pmml/v4-2-1/GeneralStructure.html>`_.
    * StatXML file, contains extended model information.

    More details about outputs, please refer to
    `LinearRegression Output Document <../../../../../output-doc/LinearRegression.html>`_.
    """

    def __init__(self, manager, java_model=None):
        super(LinearRegressionModel, self).__init__(
            manager,
            'com.ibm.spss.ml.classificationandregression.LinearRegressionModel',
            java_model)
