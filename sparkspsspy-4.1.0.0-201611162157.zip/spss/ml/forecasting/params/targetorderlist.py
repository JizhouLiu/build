#
# IBM Confidential
#
# OCO Source Materials
#
# NextGen Workbench
#
# (c) Copyright IBM Corp. 2016
#
# The source code for this program is not published or otherwise
# divested of its trade secrets, irrespective of what has been
# deposited with the U.S. Copyright Office.
#
from pyspark.mllib.common import inherit_doc

from spss.ml.common.wrapper import SPSSJavaWrapper


@inherit_doc
class TargetOrderList(object):
    def __init__(self,
                 targetList,
                 nonSeasonal=None,
                 seasonal=None,
                 secondSeasonal=None,
                 transType="none"):

        self._targetList = SPSSJavaWrapper.scalaListList(targetList)
        if nonSeasonal is None:
            self._nonSeasonal = SPSSJavaWrapper.scalaNil()
        else:
            self._nonSeasonal = SPSSJavaWrapper.scalaList(nonSeasonal)

        if seasonal is None:
            self._seasonal = SPSSJavaWrapper.scalaNil()
        else:
            self._seasonal = SPSSJavaWrapper.scalaList(seasonal)

        if secondSeasonal is None:
            self._secondSeasonal = SPSSJavaWrapper.scalaNil()
        else:
            self._secondSeasonal = SPSSJavaWrapper.scalaList(secondSeasonal)

        self._transType = transType

        self._java_object = self.value

    @property
    def value(self):
        return SPSSJavaWrapper._new_java_obj('com.ibm.spss.ml.forecasting.params.TargetOrderList',
                                             self._targetList,
                                             self._nonSeasonal,
                                             self._seasonal,
                                             self._secondSeasonal,
                                             self._transType)
