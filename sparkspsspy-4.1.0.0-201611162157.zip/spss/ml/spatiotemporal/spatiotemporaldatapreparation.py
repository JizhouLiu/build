#
# IBM Confidential
#
# OCO Source Materials
#
# NextGen Workbench
#
# (c) Copyright IBM Corp. 2016
#
# The source code for this program is not published or otherwise
# divested of its trade secrets, irrespective of what has been
# deposited with the U.S. Copyright Office.
#

from pyspark.mllib.common import inherit_doc

from spss.ml.common.wrapper import SpatioTemporalTransformer
from spss.ml.param.spatiotemporaldatapreparation import SpatioTemporalDataPreparationParams
from spss.ml.spatiotemporal.params.stemdp import RegularData, PointOccurrence, LayoutData, NewFields


@inherit_doc
class SpatioTemporalDataPreparation(SpatioTemporalTransformer, SpatioTemporalDataPreparationParams, RegularData,
                                    PointOccurrence, LayoutData, NewFields):
    """
    Spatio-temporal data preparation (STEMDP) performs the data preparation for `PPM <com.ibm.spss.ml.spatiotemporal.SpatioTemporalPointProcessModeling>`_ and `STP <com.ibm.spss.ml.spatiotemporal.SpatioTemporalPrediction>`_ modeling tools.
    It must be invoked before `PPM <com.ibm.spss.ml.spatiotemporal.SpatioTemporalPointProcessModeling>`_ or `STP <com.ibm.spss.ml.spatiotemporal.SpatioTemporalPrediction>`_ is called. It can perform data preparation for the spatial dimension, the temporal dimension, or both.

    If there are multiple raw spatio-temporal data sources with a spatial dimension, STEMDP provides the functionality to transform the multiple data sources into one single regular data source. For the temporal dimension, STEMDP provides the functionality to transform the regular or irregular time variable in date, time or timestamp format into a sequence of integer time indices.

    After transformation in STEMDP, the model-ready data for `PPM <com.ibm.spss.ml.spatiotemporal.SpatioTemporalPointProcessModeling>`_ / `STP <com.ibm.spss.ml.spatiotemporal.SpatioTemporalPrediction>`_ is a fixed set of spatial locations and a fixed set of equally spaced time indices across locations.

Example code:

    >>> from spss.ml.spatiotemporal.spatiotemporalprediction import SpatioTemporalPrediction
    >>> stemdp = SpatioTemporalDataPreparation()
    >>> stemdp = stemdp.setDataBundleType("REGULAR").
    ...	   setHasLayoutForRegDataBundle(False).
    ...	   setRegularData(RegularData(areaField="area", targetField="COUNT", coordinatesFieldList =["p0", "p1", "p2"],
    ...    timeField= "testTime", inputFieldList= ["testTime","X2","X3"])).
    ...    setStartTime(800000000.0).
    ...	   setEndTime(900000000.0).
    ...	   setInputInterval("YEAR").
    ...	   setTimeIncrement(1).
    ...    setCoordinateType("THREE_D").
    ...    setNewFields(NewFields(timeIndexField="regularTimeIndex")).
    ...	   setAutoCheckTimeRange(True).
    ...	   setIsHandleMissRecs(True)
    >>>scored = stemdp.transform(df)
   """

    def __init__(self, manager=None):
        super(SpatioTemporalDataPreparation, self).__init__(manager,
                                                            'com.ibm.spss.ml.spatiotemporal.SpatioTemporalDataPreparation')
