#
# IBM Confidential
#
# OCO Source Materials
#
# NextGen Workbench
#
# (c) Copyright IBM Corp. 2016
#
# The source code for this program is not published or otherwise
# divested of its trade secrets, irrespective of what has been
# deposited with the U.S. Copyright Office.
#

from pyspark.mllib.common import inherit_doc

from spss.ml.common.wrapper import AFUtility, ContainerManagerUtil
from spss.ml.param.rulesfiltering import RulesFilteringParams


@inherit_doc
class RulesFiltering(AFUtility, RulesFilteringParams):
    """
    Rules Filtering (RF) extracts a set of rules that meet specified criteria from an association rules model represented as PMML. RF exports new PMML that contains only those rules and can also save summary statistics for these rules.

    Example code:

    >>> con = loadContainers(["./src/test/resources/rulesfiltering/gsar_ar_rule_common.pmml.con"])
    >>> local = LocalContainerManager()
    >>> local.exportContainers("k", con)
    >>> rf = RulesFiltering(local).
    ...   setInputContainerKeys(["k"]).
    ...   setFilterByRuleSupport(True).
    ...   setRuleSupportOperator("ABOVE").
    ...   setMinRuleSupport(0.103)
    >>> result = rf.run()

    RulesFiltering exports two outputs:

    * PMML.xml file, contains model that follows `DMG PMML Standard <http://dmg.org/pmml/v4-2-1/GeneralStructure.html>`_.

    * StatXML.xml file, contains extend model information.

    More details about outputs, please refer to `RulesFiltering Output Document <../../../../../output-doc/RulesFiltering.html>`_.
    """

    def __init__(self, manager=None, pmmlString=None):
        super(RulesFiltering, self).__init__()
        java_class = 'com.ibm.spss.ml.utils.RulesFiltering'
        if pmmlString is None:
            self._java_obj = self._new_java_obj(java_class, ContainerManagerUtil.checkNoneGetJavaInstance(manager))
        else:
            self._java_obj = self._new_java_obj(java_class, pmmlString)
