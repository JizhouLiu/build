#
# IBM Confidential
#
# OCO Source Materials
#
# NextGen Workbench
#
# (c) Copyright IBM Corp. 2016
#
# The source code for this program is not published or otherwise
# divested of its trade secrets, irrespective of what has been
# deposited with the U.S. Copyright Office.
#

from pyspark.mllib.common import inherit_doc

from spss.ml.common.wrapper import Scorer
from spss.ml.param.hasadparams import HasADParamsParams
from spss.ml.param.hasassocparams import HasAssocParamsParams
from spss.ml.param.hascategoricalparams import HasCategoricalParamsParams
from spss.ml.param.hascommonparams import HasCommonParamsParams
from spss.ml.param.hascoxparams import HasCoxParamsParams
from spss.ml.param.hasensembleparams import HasEnsembleParamsParams
from spss.ml.param.hasknnparams import HasKNNParamsParams
from spss.ml.param.haskohonenparams import HasKohonenParamsParams
from spss.ml.param.hasrandomtreeparams import HasRandomTreeParamsParams
from spss.ml.param.hasregressionparams import HasRegressionParamsParams
from spss.ml.param.hasslparams import HasSLParamsParams
from spss.ml.param.hastreeparams import HasTreeParamsParams


@inherit_doc
class Score(
    Scorer,
    HasCommonParamsParams,
    HasCategoricalParamsParams,
    HasRegressionParamsParams,
    HasTreeParamsParams,
    HasCoxParamsParams,
    HasKNNParamsParams,
    HasEnsembleParamsParams,
    HasRandomTreeParamsParams,
    HasSLParamsParams,
    HasKohonenParamsParams,
    HasADParamsParams,
    HasAssocParamsParams):
    """
    A `PMML <http://dmg.org/pmml/v4-2-1/GeneralStructure.html>`_-compliant scoring engine supports:

    * PMML-compliant models (4.2 and earlier versions) produced by various vendors, except for Baseline Model, ScoreCard Model, Sequence Model, Text Model (it is deprecated, and nobody uses it). Refer to website of the Data Mining Group (DMG) for list of supported models: http://www.dmg.org/.
    * non-PMML models produced by IBM SPSS products: Discriminant and Bayesian networks.
    * PMML 4.2 transformations completely.

    Different kinds of models can produce various scoring results, for example:

    * Classification models (those with a categorical target: Bayes Net, General Regression, Mining, Naive Bayes, k-Nearest Neighbor, Neural Network, Regression, Ruleset, Support Vector Machine, Tree) produce:
    * Predicted values.
    * Probabilities
    * Confidence values.
    * Regression models (those with a continuous target: General Regression, Mining, k-Nearest Neighbor, Neural Network, Regression, Tree) produce predicted values; some also produce standard errors.
    * Cox regression (in General Regression) produces predicted survival probability and cumulative hazard values.
    * Tree models also produce Node ID.
    * Clustering models produce Cluster ID and Cluster affinity.
    * Anomaly Detection (represented as Clustering) produces anomaly index and top reasons.
    * Association model produces Consequent, Rule ID, and confidence for top matching rules.

    Example code:\n
    >>> from spss.ml.common.wrapper import LocalContainerManager
    >>> from spss.ml.score import Score
    >>> containManager = LocalContainerManager()
    >>> containManager.exportContainers("OutCon", cons)
    >>> score = Score(containManager).setInputContainerKeys(['OutCon']).setOutAll(False).
    ...     setOutInputData(False).setOutContainer(True)
    >>> df2 = score.transform(df)
    """

    def __init__(self, manager=None, pmmlString=None):
        super(Score, self).__init__(manager, 'com.ibm.spss.ml.Score', None, pmmlString)
