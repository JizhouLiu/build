#
# IBM Confidential
#
# OCO Source Materials
#
# NextGen Workbench
#
# (c) Copyright IBM Corp. 2016
#
# The source code for this program is not published or otherwise
# divested of its trade secrets, irrespective of what has been
# deposited with the U.S. Copyright Office.
#

from pyspark.mllib.common import inherit_doc

from spss.ml.common.wrapper import AFEstimator, Scorer
from spss.ml.param.randomtrees import RandomTreesParams
from spss.ml.param.hastargetfield import HasTargetFieldParams
from spss.ml.param.hasinputfieldlist import HasInputFieldListParams
from spss.ml.param.hasfreqfield import HasFreqFieldParams
from spss.ml.param.hasanalysisweightfield import HasAnalysisWeightFieldParams
from spss.ml.param.hascommonparams import HasCommonParamsParams
from spss.ml.param.hascategoricalparams import HasCategoricalParamsParams
from spss.ml.param.hasregressionparams import HasRegressionParamsParams
from spss.ml.param.hasensembleparams import HasEnsembleParamsParams
from spss.ml.param.hasrandomtreeparams import HasRandomTreeParamsParams
from spss.ml.param.haspredictioncol import HasPredictionColParams


@inherit_doc
class RandomTrees(AFEstimator, RandomTreesParams, HasTargetFieldParams, HasInputFieldListParams, HasFreqFieldParams,
                  HasAnalysisWeightFieldParams):
    """
    Random Trees is a powerful new approach for generating strong (accurate) predictive models. It is comparable and sometimes better than other state-of-the-art methods for classification or regression problems.

    Random Trees is an ensemble model consisting of multiple CART-like trees. Each tree grows on a bootstrap sample which is obtained by sampling the original data cases with replacement. Moreover, during the tree growth, for each node the best split variable is selected from a specified smaller number of variables that are drawn randomly from the full set of variables. Each tree grows to the largest extent possible, and there is no pruning. In scoring, Random Trees combines individual tree scores by majority voting (for classification) or average (for regression).

    Example code:\n
    >>> from spss.ml.classificationandregression.ensemble.randomtrees import RandomTrees
    >>> #Random trees required a "target" field and some input fields. If "target" is continuous, then regression trees will be generate else classification .
    >>> #You can use the SPSS Attribute or Spark ML Attribute to indicate the field to categorical or continuous.
    >>> randomTrees = RandomTrees().
    ...     setTargetField("target").
    ...     setInputFieldList(["feature1", "feature2", "feature3"]).
    ...     numTrees(10).
    ...     setMaxTreeDepth(5)
    >>> randomTreesModel = randomTrees.fit(df)
    >>> predictions = randomTreesModel.transform(scoreDF)
    >>> predictions.show()
    """

    def __init__(self, manager=None):
        super(RandomTrees, self).__init__(manager, 'com.ibm.spss.ml.classificationandregression.ensemble.RandomTrees')

    def _create_model(self, java_model):
        return RandomTreesModel(None, java_model)


@inherit_doc
class RandomTreesModel(Scorer, HasCommonParamsParams, HasCategoricalParamsParams, HasRegressionParamsParams,
                       HasEnsembleParamsParams, HasRandomTreeParamsParams, HasPredictionColParams):
    """
    Model produced by :class:`RandomTrees`.

    RandomTrees exports two outputs:

    * PMML file, contains model that follows `DMG PMML Standard <http://dmg.org/pmml/v4-2-1/TreeModel.html>`_.
    * StatXML file, contains extended model information.

    More details about outputs, please refer to `RandomTrees Output Document <../../../../../../output-doc/RandomTrees.html>`_.
    """

    def __init__(self, manager, java_model=None):
        super(RandomTreesModel, self).__init__(manager,
                                               'com.ibm.spss.ml.classificationandregression.ensemble.RandomTreesModel',
                                               java_model)
