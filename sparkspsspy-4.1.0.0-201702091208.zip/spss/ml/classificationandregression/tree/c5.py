#
# IBM Confidential
#
# OCO Source Materials
#
# NextGen Workbench
#
# (c) Copyright IBM Corp. 2016
#
# The source code for this program is not published or otherwise
# divested of its trade secrets, irrespective of what has been
# deposited with the U.S. Copyright Office.
#

from pyspark.mllib.common import inherit_doc
from pyspark.ml.wrapper import JavaEstimator, JavaModel

from spss.ml.param.c5 import C5Params
from spss.ml.param.hasfreqfield import HasFreqFieldParams
from spss.ml.param.hasanalysisweightfield import HasAnalysisWeightFieldParams
from spss.ml.param.hasinputfieldlist import HasInputFieldListParams
from spss.ml.param.haspredictioncol import HasPredictionColParams
from spss.ml.param.hasprobabilityparams import HasProbabilityParamsParams
from spss.ml.param.hastargetfield import HasTargetFieldParams
from spss.ml.common.wrapper import PMMLExportable, StatXMLExportable

@inherit_doc
class C5(JavaEstimator, C5Params,HasFreqFieldParams,HasAnalysisWeightFieldParams,HasInputFieldListParams,HasTargetFieldParams,HasPredictionColParams, HasProbabilityParamsParams ):
    """
    Classification Tree

    C5.0 is an improvement on C4.5. Besides the features of C4.5,major new features include:
    Group symbolics,Use boosting,Use global pruning,Winnow attributes (feature selection).
    C4.5 is one of the most well-known decision tree algorithms. Developed by Quinlan in 1993,it is an extension of basic ID3 algorithm .
    The improvements of C4.5 include:
    Employ information gain ratio instead of information gain as a measurement to select splitting attributes.not only discrete attributes, but also continuous ones can be handled and Handling incomplete training data with missing values,prune during the construction of trees to avoid over-fitting.

    Example code:

    >>> from spss.ml.classificationandregression.tree.c5 import C5
    >>> c5 = C5().
    >>> setTargetField("salary").
    >>> setInputFieldList(["educ", "jobcat", "gender"])
    >>> c5Model = c5.fit(data)
    >>> pmmlStr = c5Model.toPMML()
    >>> statxmlStr = c5Model.statXML()
    >>> predictions = c5Model.transform(data)
    >>> predictions.show()
    """

    def __init__(self):
        super(C5, self).__init__()
        self._java_obj = self._new_java_obj(
                "com.ibm.spss.ml.classificationandregression.tree.c5.C5", self.uid)

    def _create_model(self, java_model):
        return C5Model(java_model)


class C5Model(JavaModel,PMMLExportable, StatXMLExportable):
    """
    Model produced by [[C5]].

    C5 exports two outputs:
     - PMML file, contains model that follows [[http://dmg.org/pmml/v4-2-1/GeneralStructure.html DMG PMML Standard]].
     - StatXML file, contains extended model information.

    For more details about outputs, please refer to
    `C5 Output Document <../../../../../../../output-doc/C5.html>`_.
    """