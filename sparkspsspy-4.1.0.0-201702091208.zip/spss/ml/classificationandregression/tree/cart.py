#
# IBM Confidential
#
# OCO Source Materials
#
# NextGen Workbench
#
# (c) Copyright IBM Corp. 2016
#
# The source code for this program is not published or otherwise
# divested of its trade secrets, irrespective of what has been
# deposited with the U.S. Copyright Office.
#

from pyspark.mllib.common import inherit_doc
from pyspark.ml.wrapper import JavaEstimator, JavaModel

from spss.ml.param.cart import CARTParams
from spss.ml.param.hasfreqfield import HasFreqFieldParams
from spss.ml.param.hasanalysisweightfield import HasAnalysisWeightFieldParams
from spss.ml.param.hasinputfieldlist import HasInputFieldListParams
from spss.ml.param.haspredictioncol import HasPredictionColParams
from spss.ml.param.hasprobabilityparams import HasProbabilityParamsParams
from spss.ml.param.hastargetfield import HasTargetFieldParams
from spss.ml.common.wrapper import PMMLExportable, StatXMLExportable

@inherit_doc
class CART(JavaEstimator, CARTParams,HasFreqFieldParams,HasAnalysisWeightFieldParams,HasInputFieldListParams,HasTargetFieldParams,HasPredictionColParams, HasProbabilityParamsParams ):
    """
    Classification And Regression Tree


    A CART tree is a binary decision tree that is constructed by splitting a node into two child nodes repeatedly,
    starting from the root node that contains the entire learning sample.
    Growing a CART tree on a massive data imposes critical performance issues,
    particularly in sorting continuous predictors, handling a large number of predictors.
    These issues will be addressed efficiently when we implement the scalable CART tree component in the distributed setting.
    In addition to generating the predictive model, we also provide an enhanced set of evaluation and diagnostic features enabling insight,
    interactivity, and an improved overall user experience as required by the existing applications.

    Example code:

    >>> from spss.ml.classificationandregression.tree.cart import CART
    >>> cart = CART().
    ...     setTargetField("salary").
    ...     setInputFieldList(["educ", "jobcat", "gender"])
    >>> cartModel = cart.fit(data)
    >>> pmmlStr = cartModel.toPMML()
    >>> statxmlStr = cartModel.statXML()
    >>> predictions = cartModel.transform(data)
    >>> predictions.show()
    """

    def __init__(self):
        super(CART, self).__init__()
        self._java_obj = self._new_java_obj(
                "com.ibm.spss.ml.classificationandregression.tree.cart.CART", self.uid)

    def _create_model(self, java_model):
        return CARTModel(java_model)


class CARTModel(JavaModel,PMMLExportable, StatXMLExportable):
    """
    Model produced by [[CART]].

    CART exports two outputs:
     - PMML file, contains model that follows [[http://dmg.org/pmml/v4-2-1/GeneralStructure.html DMG PMML Standard]].
     - StatXML file, contains extended model information.

    For more details about outputs, please refer to
    `CART Output Document <../../../../../../../output-doc/CART.html>`_.
    """