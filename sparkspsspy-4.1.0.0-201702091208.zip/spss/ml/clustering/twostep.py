#
# IBM Confidential
#
# OCO Source Materials
#
# NextGen Workbench
#
# (c) Copyright IBM Corp. 2016
#
# The source code for this program is not published or otherwise
# divested of its trade secrets, irrespective of what has been
# deposited with the U.S. Copyright Office.
#

from pyspark.mllib.common import inherit_doc

from spss.ml.common.wrapper import AFEstimator, Scorer
from spss.ml.param.hascommonparams import HasCommonParamsParams
from spss.ml.param.hasprobabilityparams import HasProbabilityParamsParams
from spss.ml.param.twostep import TwoStepParams
from spss.ml.param.hasinputfieldlist import HasInputFieldListParams


@inherit_doc
class TwoStep(AFEstimator, TwoStepParams, HasInputFieldListParams):
    """
    Scalable Two-Step is based on the familiar two-step clustering algorithm but extends both its functionality and performance in several directions.

    First, it can effectively work with large and distributed data supported by Spark that provides the Map-Reduce computing paradigm.

    Second, the algorithm provides mechanisms for selecting the most relevant features for clustering the given data, as well as detecting rare outlier points. Moreover, it provides an enhanced set of evaluation and diagnostic features for enabling insight.

    The algorithm of two-step clustering first performs a pre-clustering step by scanning the entire dataset and storing the dense regions of data cases in terms of summary statistics called cluster features. The cluster features are stored in memory in a data structure called the CF-tree. Finally, an agglomerative hierarchical clustering algorithm is applied to cluster the set of cluster features.

    Example code:

    >>> from spss.ml.clustering.twostep import TwoStep
    >>> cluster = TwoStep().
    ...     setInputFieldList(["region", "happy", "age"]).
    ...     setDistMeasure("LOGLIKELIHOOD").
    ...     setFeatureImportanceMethod("CRITERION").
    ...     setAutoClustering(True)
    >>> clusterModel = cluster.fit(data)
    >>> pmmlStr = clusterModel.toPMML()
    >>> statxmlStr = clusterModel.statXML()
    >>> predictions = clusterModel.transform(data)
    >>> predictions.show()
    """

    def __init__(self, manager=None):
        super(TwoStep, self).__init__(manager, 'com.ibm.spss.ml.clustering.TwoStep')

    def _create_model(self, java_model):
        return TwoStepModel(None, java_model)


class TwoStepModel(Scorer, HasCommonParamsParams, HasProbabilityParamsParams):
    """
    Model produced by :class:`TwoStep`.

    TwoStep exports two outputs:

    * PMML file, contains model that follows `DMG PMML Standard <http://dmg.org/pmml/v4-2-1/GeneralStructure.html>`_.
    * StatXML file, contains extended model information.

    More details about outputs, please refer to
    `TwoStep Output Document <../../../../../../output-doc/TwoStep.html>`_.
    """

    def __init__(self, manager, java_model=None):
        super(TwoStepModel, self).__init__(manager, 'com.ibm.spss.ml.clustering.TwoStepModel', java_model)
