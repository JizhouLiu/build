#
# IBM Confidential
#
# OCO Source Materials
#
# NextGen Workbench
#
# (c) Copyright IBM Corp. 2016
#
# The source code for this program is not published or otherwise
# divested of its trade secrets, irrespective of what has been
# deposited with the U.S. Copyright Office.
#

from pyspark.mllib.common import inherit_doc

from pyspark.ml.wrapper import JavaTransformer
from spss.ml.common.wrapper import ContainerCapability
from spss.ml.param.hexbinning import HexBinningParams


@inherit_doc
class HexBinning(JavaTransformer, HexBinningParams, ContainerCapability):
    """
    The function can be used to calculate and assign hexagonal bins to two fields.

    Example code:

    >>> from spss.ml.datapreparation.binning.hexbinning import HexBinning
    >>> from spss.ml.param.binningsettings import HexBinningSetting
    >>> params = [HexBinningSetting("field1_out", "field1", 5, -1.0, 25.0, 5.0),
    ...           HexBinningSetting("field2_out", "field2", 5, -1.0, 25.0, 5.0)]
    >>> hexBinning = HexBinning().setHexBinRequestsParam(params)
    >>> outputDF = hexBinning.transform(inputDF)
    """

    def __init__(self):
        super(HexBinning, self).__init__()
        self._java_obj = self._new_java_obj('com.ibm.spss.ml.datapreparation.binning.HexBinning')
