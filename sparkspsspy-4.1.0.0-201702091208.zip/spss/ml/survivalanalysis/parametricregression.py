#
# IBM Confidential
#
# OCO Source Materials
#
# NextGen Workbench
#
# (c) Copyright IBM Corp. 2016
#
# The source code for this program is not published or otherwise
# divested of its trade secrets, irrespective of what has been
# deposited with the U.S. Copyright Office.
#

from pyspark.mllib.common import inherit_doc

from spss.ml.common.wrapper import AFEstimator, Scorer
from spss.ml.param.hascommonparams import HasCommonParamsParams
from spss.ml.param.hasstatusfield import HasStatusFieldParams
from spss.ml.param.hassurvivaltimefield import HasSurvivalTimeFieldParams
from spss.ml.param.parametricregression import ParametricRegressionParams


@inherit_doc
class ParametricRegression(AFEstimator,
                                ParametricRegressionParams,
                                HasSurvivalTimeFieldParams,
                                HasStatusFieldParams):
    """
       Parametric regression modeling (PRM) is a survival analysis technique that     incorporates the effects of covariates on the survival times. PRM includes two model types, accelerated failure time and frailty. Accelerated failure time models assume that the relationship of the logarithm of survival time and the covariates is linear. Frailty, or random effects, models are useful for analyzing recurrent events, correlated survival data, or when observations are clustered into groups.
       PRM automatically selects the survival time distribution (exponential, Weibull,log-normal, or log-logistic) that best describes the survival times.

       Example code:

       >>> from spss.ml.survivalanalysis.parametricregression import ParametricRegression, ParametricRegressionModel
       >>> defined_status = DefinedStatus(
       ...     failure=StatusItem(points=Points(["F"])),
       ...     rightCensored=StatusItem(points=Points(["R"])),
       ...     leftCensored=StatusItem(points=Points(["L"])),
       ...     intervalCensored=StatusItem(points=Points(["I"]))
       ...     )
       >>> prm = ParametricRegression().
       ...     setBeginField("startTime").
       ...     setEndField("endTime").
       ...     setStatusField("status").
       ...     setPredictorFields(["age", "surgery", "transplant"]).
       ...     setDefinedStatus(defined_status).
       ...     setDefaultScale(True)
       >>> model = prm.fit(df)
       >>> c = model.containerSeq()
       >>> predictions = model.transform(df)
       """

    def __init__(self, manager=None):
        super(ParametricRegression, self).__init__(manager, 'com.ibm.spss.ml.survivalanalysis.ParametricRegression')

    def _create_model(self, java_model):
        return ParametricRegressionModel(None, java_model)


@inherit_doc
class ParametricRegressionModel(Scorer,HasCommonParamsParams):
    """
   Model produced by :class:`ParametricRegression`.

    ParametricRegression exports two outputs:
    * PMML file, contains model that follows `DMG PMML Standard <http://dmg.org/pmml/v4-2-1/GeneralStructure.html>`_.
    * StatXML file, contains extended model information.

    More details about outputs, please refer to `ParametricRegression Output Document <../../../../../output-doc/ParametricRegression.html>`_.
   """

    def __init__(self, manager, java_model=None):
        super(ParametricRegressionModel, self).__init__(manager, 'com.ibm.spss.ml.survivalanalysis.ParametricRegressionModel', java_model)
