#
# IBM Confidential
#
# OCO Source Materials
#
# NextGen Workbench
#
# (c) Copyright IBM Corp. 2016
#
# The source code for this program is not published or otherwise
# divested of its trade secrets, irrespective of what has been
# deposited with the U.S. Copyright Office.
#
from spss.ml.common.wrapper import SPSSJavaWrapper


class DefinedStatus(object):
    def __init__(self, failure=None, rightCensored=None, leftCensored=None, intervalCensored=None):
        if failure is None:
            self._failure = SPSSJavaWrapper.scalaNone()
        else:
            self._failure = failure.value()

        if rightCensored is None:
            self._rightCensored = SPSSJavaWrapper.scalaNone()
        else:
            self._rightCensored = rightCensored.value()

        if leftCensored is None:
            self._leftCensored = SPSSJavaWrapper.scalaNone()
        else:
            self._leftCensored = leftCensored.value()

        if intervalCensored is None:
            self._intervalCensored = SPSSJavaWrapper.scalaNone()
        else:
            self._intervalCensored = intervalCensored.value()

    def value(self):
        return SPSSJavaWrapper._new_java_obj('com.ibm.spss.ml.survivalanalysis.params.DefinedStatus', self._failure,
                                             self._rightCensored, self._leftCensored, self._intervalCensored)


class StatusItem(object):
    def __init__(self, range=None, points=None):

        if range is None:
            self._range = SPSSJavaWrapper.scalaNone()
        else:
            self._range = range.value()

        if points is None:
            self._points = SPSSJavaWrapper.scalaNone()
        else:
            self._points = points.value()

    def value(self):
        v = SPSSJavaWrapper._new_java_obj('com.ibm.spss.ml.survivalanalysis.params.StatusItem', self._range,
                                          self._points)
        return SPSSJavaWrapper.scalaSome(v)


class StatusRange(object):
    def __init__(self, fro, to):
        self._fro = fro
        self._to = to

    def value(self):
        return SPSSJavaWrapper._new_java_obj('com.ibm.spss.ml.survivalanalysis.params.StatusRange', self._fro, self._to)


class Points(object):
    def __init__(self, points):
        from spss.ml.common.wrapper import SPSSJavaWrapper
        self._points = SPSSJavaWrapper.scalaList(points)

    def value(self):
        v = SPSSJavaWrapper._new_java_obj('com.ibm.spss.ml.survivalanalysis.params.Points', self._points)
        return SPSSJavaWrapper.scalaSome(v)
