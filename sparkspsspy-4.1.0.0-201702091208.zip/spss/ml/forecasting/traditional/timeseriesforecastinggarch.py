#
# IBM Confidential
#
# OCO Source Materials
#
# NextGen Workbench
#
# (c) Copyright IBM Corp. 2016
#
# The source code for this program is not published or otherwise
# divested of its trade secrets, irrespective of what has been
# deposited with the U.S. Copyright Office.
#

from pyspark.mllib.common import inherit_doc

from spss.ml.param.timeseriesforecastingcrostonparams import HasTargets
from spss.ml.param.timeseriesforecastingparams import TimeSeriesForecastingParams
from spss.ml.common.wrapper import DirectorScorer, AFEstimator, PMMLWriter
from spss.ml.param.hasscorecrostonparams import HasInitContainerKeyParams
from spss.ml.param.timeseriesforecastinggarchparams import TimeSeriesForecastingGarchParamsParams

@inherit_doc
class TimeSeriesForecastingGarch(AFEstimator,
                                 TimeSeriesForecastingParams,
                                 TimeSeriesForecastingGarchParamsParams
                                 ):

    """
    Many time series often show random varying variances, which is also called "realized volatility" and often of great
    importance.GARCH(Generalized Auto Regression Conditional Heteroscedasticity ) models are widely used to characterize
    and model time series with time-varying volatility. GARCH models assume the variance of the current error term to be
    a linear function of the squares of the previous errors and their variances.

    Example code:\n
    >>> from spss.ml.common.wrapper import LocalContainerManager
    >>> from spss.ml.forecasting.reversetimeseriesdatapreparation import ReverseTimeSeriesDataPreparation
    >>> from spss.ml.forecasting.timeseriesdatapreparation import TimeSeriesDataPreparation
    >>> from spss.ml.forecasting.traditional.timeseriesforecastinggarch import TimeSeriesForecastingGarch
    >>> from spss.ml.forecasting.params.temporal import Fit, ForecastEs
    >>> from spss.ml.forecasting.params.predictor import Predictor,ScorePredictor
    >>> from spss.ml.param.timeseriesforecastinggarchparams import TargetOrderListGarch, ConvergenceCriterion
    >>> from spsstest.spsspysparktest import SPSSPySparkTest
    >>> tsdp = TimeSeriesDataPreparation().
    ...    setMetricFieldList(["DEM2GBP"]).
    ...    setDateTimeField("Date").
    ...    setEncodeSeriesID(True).
    ...    setInputTimeInterval("DAY").
    ...    setOutTimeInterval("DAY").
    ...    setQualityScoreThreshold(0.0).
    ...    setConstSeriesThreshold(0.0)
    >>>  tsdp_df = tsdp.transform(df)
    >>>  tsdp_container = tsdp.containers()
    >>>  lcm = LocalContainerManager()
    >>>  lcm.exportContainers("Container", tsdp_container)
    >>>  targList = [["DEM2GBP"]]
    >>>  targetOrderListGarch = [GarchTargetOrderList(targetList, 2, 3, 1, 2)]
    >>>  garch = TimeSeriesForecastingGarch(lcm).
    ...    setTargetOrderList(targetOrderListGARCH).
    ...    setInputContainerKeys(["Container"]).
    ...    setLogLHConvergCriterion(ConvergenceCriterion(False, True, 1e-6)).
    ...    setHessianConvergCriterion(ConvergenceCriterion(False, True, 1e-4)).
    ...    setOptSolver("Newton").
    ...    setOutIterHistory(True)
    >>>  garch_model = garch.fit(tsdp_df)
    >>>  tsdp_score = TimeSeriesDataPreparation().
    ...    setMetricFieldList(["DEM2GBP"]).
    ...    setDateTimeField("Date").
    ...    setEncodeSeriesID(True).
    ...    setInputTimeInterval("DAY").
    ...    setOutTimeInterval("DAY").
    ...    setQualityScoreThreshold(0.0).
    ...    setConstSeriesThreshold(0.0)
    >>>  tsdp_df_score = tsdp_score.transform(df_score)
    >>>  tsdp_container_score = tsdp_score.containers()
    >>>  lcm.exportContainers("ScoreDataTSDPContainer", tsdp_container_score)
    >>>  sp = ScorePredictor()
    >>>  fitsettings = Fit(outFit = True, outCI = True, outResidual = False)
    >>>  forecast = ForecastEs(outForecast = True, outCI = False)
    >>>  garch_model.setTargets(sp).
    ...    setFitSettings(fit).
    ...    setForecast(forecast).
    ...    setInputContainerKeys(["Container"]).
    >>>  garchForecastDf = garch_model.transform(tsdp_df_score)
    >>>  rtsdp = ReverseTimeSeriesDataPreparation(lcm).
    ...    setDeriveFutureIndicatorField(True).
    ...    setInputContainerKeys(["ScoreDataTSDPContainer", "ScoreOutput"])
    >>>  rtsdpDF = rtsdp.transform(garchForecastDf)
    """

    def __init__(self, manager):
        super(TimeSeriesForecastingGarch, self).__init__(manager,
                                                         'com.ibm.spss.ml.forecasting.traditional.TimeSeriesForecastingGarch')

    def _create_model(self, java_model):
        return TimeSeriesForecastingGarchModel(None, java_model)


class TimeSeriesForecastingGarchModel(DirectorScorer,
                                      TimeSeriesForecastingParams,
                                      HasTargets,
                                      HasInitContainerKeyParams,
                                      PMMLWriter):
    """
    Model fitted by TimeSeriesForecastingGarchModel.

    TimeSeriesForecastingGarch exports outputs:

    * PMML file, contains TimeSeriesForecasting model information.
    * StatXML file, contains extended model information.

    More details about outputs, please refer to `TimeSeries Garch Output Document <../../../../../../output-doc/TimeSeriesGarch.html>`_.
    """

    def __init__(self, manager, java_model=None):
        super(TimeSeriesForecastingGarchModel, self).__init__(manager,
                                                              'com.ibm.spss.ml.forecasting.traditional.TimeSeriesForecastingGarchModel',
                                                              java_model)
