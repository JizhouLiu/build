#
# IBM Confidential
#
# OCO Source Materials
#
# NextGen Workbench
#
# (c) Copyright IBM Corp. 2016
#
# The source code for this program is not published or otherwise
# divested of its trade secrets, irrespective of what has been
# deposited with the U.S. Copyright Office.
#

from pyspark.mllib.common import inherit_doc

from spss.ml.common.wrapper import AFTransformer, ContainerCapability, AFUtility
from spss.ml.param.timeseriesdatapreparation import TimeSeriesDataPreparationParams
from spss.ml.param.timeseriesdatapreparationconvertor import TimeSeriesDataPreparationConvertorParams


@inherit_doc
class TimeSeriesDataPreparation(AFTransformer, ContainerCapability, TimeSeriesDataPreparationParams):
    """
    Data preparation for time series data (TSDP) provides the functionality that converts raw time
    data (in Flattened multi-dimensional format, which includes transactional (event) based and column-based data)
    into regular time series data (in compact row-based format) which is required by the subsequent time series analysis methods.
    The main job of TSDP is to generate time series in terms of the combination of each unique value in the dimension fields with metric fields.
    In addition, it sorts the data based on the timestamp, extracts metadata of time variables, transforms time series with another
    time granularity (interval) by applying an aggregation or distribution function, checks the data quality, and handles missing values if needed.

    Example code:

    >>> from spss.ml.forecasting.timeseriesdatapreparation import TimeSeriesDataPreparation
    >>> tsdp = TimeSeriesDataPreparation().
    ...        setMetricFieldList(["Demand"]).
    ...        setDateTimeField("Date").
    ...        setEncodeSeriesID(True).
    ...        setInputTimeInterval("MONTH").
    ...        setOutTimeInterval("MONTH").
    ...        setQualityScoreThreshold(0.0).
    ...        setConstSeriesThreshold(0.0)
    >>> tsdpOut = tsdp.transform(data)

    :param manager: the ContainerStateManager instance that holds the require input containers under the specified key

    TimeSeriesDataPreparation exports outputs:
     * JSON file, contains model information.

    More details about outputs, please refer to
    `TimeSeriesDataPreparation Output Document <../../../../../../output-doc/TimeSeriesDataPreparation.html>`_.
    """

    def __init__(self, manager=None):
        super(TimeSeriesDataPreparation, self).__init__(manager,
                                                        'com.ibm.spss.ml.forecasting.TimeSeriesDataPreparation')


@inherit_doc
class TimeSeriesDataPreparationConvertor(AFUtility, TimeSeriesDataPreparationConvertorParams):
    """
    Date time convertor API that is used to provide some functionalities of date/time convertor inside TSDP for applications to use. There are two use cases for this component: Compute the time points between a specified start and end time. (In this case the start and end time both occur after the first observation in the previous TSDP's output. ) Compute the time points between a start index and end index referring to the last observation in the previous TSDP's output.

    :param manager: the ContainerStateManager instance that holds the require input containers under the specified key
    """

    def __init__(self, manager):
        super(TimeSeriesDataPreparationConvertor, self).__init__()
        self._java_obj = self._new_java_obj("com.ibm.spss.ml.forecasting.TimeSeriesDataPreparationConvertor",
                                            manager._java_instance)
