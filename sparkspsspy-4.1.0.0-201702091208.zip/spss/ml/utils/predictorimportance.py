#
# IBM Confidential
#
# OCO Source Materials
#
# NextGen Workbench
#
# (c) Copyright IBM Corp. 2016
#
# The source code for this program is not published or otherwise
# divested of its trade secrets, irrespective of what has been
# deposited with the U.S. Copyright Office.
#

from pyspark.mllib.common import inherit_doc

from spss.ml.common.wrapper import AFEstimator
from spss.ml.common.wrapper import IdentityScorer
from spss.ml.common.wrapper import PMMLExportable


@inherit_doc
class PredictorImportance(AFEstimator):
    """
    Predictor importance (PI) produces an appropriate statistical measure on the predictor fields in estimating a model.
    It uses a variance-based sensitivity analysis algorithm to generate a chart by sorting the relative importance of
    each predictor in descending order. PI is available for the algorithms including neural networks, decision trees,
    Bayesian networks, discriminant analysis, support vector machines (SVM), linear and logistic regression models,
    generalized linear models, and k-nearest neighbors (KNN) models.

    Example code:

    >>> local = LocalContainerManager()
    >>> local.exportContainers("k", con)
    >>> estimator = PredictorImportance(local).
    ...     setInputContainerKeys(["k"])
    >>> piModel = estimator.fit(df)
    """

    def __init__(self, manager=None, pmmlString=None):
        super(PredictorImportance, self).__init__(manager, "com.ibm.spss.ml.utils.PredictorImportance", pmmlString)

    def _create_model(self, java_model):
        return PredictorImportanceModel(None, java_model)


class PredictorImportanceModel(IdentityScorer, PMMLExportable):
    """
    Model produced by :class:`PredictorImportance`.

    PredictorImportance exports outputs:

    * PMML file, contains model that follows `DMG PMML Standard <http://dmg.org/pmml/v4-2-1/GeneralStructure.html>`_.

    More details about outputs, please refer to
    `PredictorImportance Output Document <../../../../../../output-doc/PredictorImportance.html>`_.
    """

    def __init__(self, manager, java_model=None):
        super(PredictorImportanceModel, self).__init__(manager, 'com.ibm.spss.ml.utils.PredictorImportanceModel',
                                                       java_model)
