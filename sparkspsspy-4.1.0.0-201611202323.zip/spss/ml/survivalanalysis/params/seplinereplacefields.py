#
# IBM Confidential
#
# OCO Source Materials
#
# NextGen Workbench
#
# (c) Copyright IBM Corp. 2016
#
# The source code for this program is not published or otherwise
# divested of its trade secrets, irrespective of what has been
# deposited with the U.S. Copyright Office.
#
from spss.ml.common.wrapper import SPSSJavaWrapper


class SepLineReplaceFields(object):
    def __init__(self, sepLineFieldName, sepLineFiledValue):
        self._sepLineFieldName = sepLineFieldName
        self._sepLineFiledValue = sepLineFiledValue

    def value(self):
        return SPSSJavaWrapper._new_java_obj('com.ibm.spss.ml.survivalanalysis.params.SepLineReplaceFields', self._sepLineFieldName, self._sepLineFiledValue)
