#
# IBM Confidential
#
# OCO Source Materials
#
# NextGen Workbench
#
# (c) Copyright IBM Corp. 2016
#
# The source code for this program is not published or otherwise
# divested of its trade secrets, irrespective of what has been
# deposited with the U.S. Copyright Office.
#

from pyspark.mllib.common import inherit_doc

from spss.ml.common.wrapper import AFEstimator, Scorer
from spss.ml.param.chaid import CHAIDParams
from spss.ml.param.hascategoricalparams import HasCategoricalParamsParams
from spss.ml.param.hascommonparams import HasCommonParamsParams
from spss.ml.param.hasregressionparams import HasRegressionParamsParams
from spss.ml.param.hastreeparams import HasTreeParamsParams
from spss.ml.param.hastargetfield import HasTargetFieldParams
from spss.ml.param.haspredictioncol import HasPredictionColParams


@inherit_doc
class CHAID(AFEstimator, CHAIDParams, HasTargetFieldParams):
    """
    CHAID, or Chi-squared Automatic Interaction Detection, is a classification method
    for building decision trees by using chi-square statistics to identify optimal splits.
    An extension applicable to regression problems is also available.

    CHAID first examines the crosstabulations between each of the input fields and the target,
    and tests for significance using a chi-square independence test. If more than one of
    these relations is statistically significant, CHAID will select the input field
    that is the most significant (smallest p value). If an input has more than two categories,
    these are compared, and categories that show no differences in the outcome are collapsed
    together. This is done by successively joining the pair of categories showing the least
    significant difference. This category-merging process stops when all remaining categories
    differ at the specified testing level. For nominal input fields, any categories can be
    merged; for an ordinal set, only contiguous categories can be merged. Continuous input
    fields other than the target cannot be used directly; they must be binned into ordinal
    fields first.

    Exhaustive CHAID is a modification of CHAID that does a more thorough job of examining
    all possible splits for each predictor but takes longer to compute.

    Example code:

    >>> from spss.ml.classificationandregression.tree.chaid import CHAID
    >>> chaid = CHAID().
    ...     setTargetField("salary").
    ...     setInputFieldList(["educ", "jobcat", "gender"])
    >>> chaidModel = chaid.fit(data)
    >>> pmmlStr = chaidModel.toPMML()
    >>> statxmlStr = chaidModel.statXML()
    >>> predictions = chaidModel.transform(data)
    >>> predictions.show()
    """

    def __init__(self, manager=None):
        super(CHAID, self).__init__(manager, 'com.ibm.spss.ml.classificationandregression.tree.CHAID')

    def _create_model(self, java_model):
        return CHAIDModel(None, java_model)


class CHAIDModel(Scorer,
                 HasCommonParamsParams,
                 HasCategoricalParamsParams,
                 HasRegressionParamsParams,
                 HasTreeParamsParams,
                 HasPredictionColParams):
    """
    Model produced by :class:`CHAID`.

    CHAID exports two outputs:

    * PMML file, contains model that follows `DMG PMML Standard <http://dmg.org/pmml/v4-2-1/TreeModel.html>`_.
    * StatXML file, contains extended model information.

    More details about outputs, please refer to
    `CHAID Output Document <../../../../../../output-doc/CHAID.html>`_.
    """

    def __init__(self, manager, java_model=None):
        super(CHAIDModel, self).__init__(manager, 'com.ibm.spss.ml.classificationandregression.tree.CHAIDModel',
                                         java_model)
