#
# IBM Confidential
#
# OCO Source Materials
#
# NextGen Workbench
#
# (c) Copyright IBM Corp. 2016
#
# The source code for this program is not published or otherwise
# divested of its trade secrets, irrespective of what has been
# deposited with the U.S. Copyright Office.
#

from pyspark.ml.wrapper import JavaTransformer
from pyspark.mllib.common import inherit_doc
from spss.ml.common.wrapper import Containers
from spss.ml.param.reencode import ReEncodeFieldParams


@inherit_doc
class ReEncodeField(JavaTransformer, Containers, ReEncodeFieldParams):
    """
    Re-encode Field (RF) generates new encoding values for encoded categorical input
    data. The new values depend on the RF settings. The output data model is updated in accordance with the new categorical values order.

    Example code:

    >>> from spss.ml.common.wrapper import LocalContainerManager
    >>> from spss.ml.param.reencode import FlagField, NominalField, OrdinalField, ReEncodeFieldValue
    >>> from spss.ml.utils.reencodefield import ReEncodeField
    >>> lcm = LocalContainerManager()
    >>> transformer = ReEncodeField(lcm).
    ...               setInputContainerKeys(["k"]).
    ...               setReencodeFieldSetting(ReEncodeFieldValue(
    ...                                       reencodeFieldNameList = ["metric", "db"],
    ...                                       nominalField = NominalField(["DataModel_ar", "DataModel_tcm"])))
    >>> ref = transformer.transform(tsdp_df)
    """

    def __init__(self, manager):
        super(ReEncodeField, self).__init__()        
        self._java_obj = self._new_java_obj('com.ibm.spss.ml.utils.ReEncodeField',
                                            manager._java_instance, self.uid)
