#
# IBM Confidential
#
# OCO Source Materials
#
# NextGen Workbench
#
# (c) Copyright IBM Corp. 2016
#
# The source code for this program is not published or otherwise
# divested of its trade secrets, irrespective of what has been
# deposited with the U.S. Copyright Office.
#

from pyspark.mllib.common import inherit_doc

from spss.ml.common.wrapper import AFTransformer
from spss.ml.param.countandsample import CountAndSampleParams


@inherit_doc
class CountAndSample(AFTransformer, CountAndSampleParams):
    """
    The countAndSample function produces a pseudo-random sample having a size approximately equal to the input 'samplingCount'.
    The sampling is accomplished by calling the SamplingComponent with a sampling ratio that is computed as 'samplingCount / totalRecords' where 'totalRecords' is the record count of the incoming data.

    Example code:

    >>> from spss.ml.datapreparation.sampling.countandsample import CountAndSample
    >>> randomSeed = 123
    >>> count = 20000
    >>> sample = CountAndSample().setSamplingCount(count).setRandomSeed(randomSeed)
    >>> odf = sample.transform(df)

    """
    def __init__(self, manager=None):
        super(CountAndSample, self).__init__(manager, 'com.ibm.spss.ml.datapreparation.sampling.CountAndSample')
