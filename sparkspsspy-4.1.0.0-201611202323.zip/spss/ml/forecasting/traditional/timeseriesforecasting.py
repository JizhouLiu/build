# coding=utf-8
#
# IBM Confidential
#
# OCO Source Materials
#
# NextGen Workbench
#
# (c) Copyright IBM Corp. 2016
#
# The source code for this program is not published or otherwise
# divested of its trade secrets, irrespective of what has been
# deposited with the U.S. Copyright Office.
#

from pyspark.mllib.common import inherit_doc

from spss.ml.common.wrapper import OutputDataCapabilitiesEstimator, DirectorScorer
from spss.ml.param.hascilevel import HasCILevelParams
from spss.ml.param.hasesoutlier import HasESOutlierParams
from spss.ml.param.hasexportparams import HasExportParamsParams
from spss.ml.param.hasscoreparams import HasScoreParamsParams
from spss.ml.param.hasseasonlength import HasSeasonLengthParams
from spss.ml.param.timeseriesforecastingarima import TimeSeriesForecastingArimaParams
from spss.ml.param.timeseriesforecastingexpert import TimeSeriesForecastingExpertParams
from spss.ml.param.timeseriesforecastingexponentialsmoothing import TimeSeriesForecastingExponentialSmoothingParams
from spss.ml.param.timeseriesforecastingmodel import TimeSeriesForecastingModelParams
from spss.ml.param.timeseriesforecastingmodelreestimate import TimeSeriesForecastingModelReEstimateParams


@inherit_doc
class TimeSeriesForecastingExpert(OutputDataCapabilitiesEstimator,
                                  TimeSeriesForecastingExpertParams,
                                  HasESOutlierParams,
                                  HasExportParamsParams,
                                  HasScoreParamsParams,
                                  HasSeasonLengthParams,
                                  HasCILevelParams):
    """
    Expert modeler for time series forecasting is an automatic model identification tool. It applies some time series model, such as ARIMA and/or exponential smoothing, to a specified target series and then recommends a model or top N models based on a model quality measure.

    Example code:

    >>> from spss.ml.forecasting.timeseriesdatapreparation import TimeSeriesDataPreparation
    >>> from spss.ml.forecasting.traditional.timeseriesforecasting import TimeSeriesForecastingExpert
    >>> from spss.ml.forecasting.reversetimeseriesdatapreparation import ReverseTimeSeriesDataPreparation
    >>> from spss.ml.forecasting.params.predictor import TSCExpertPredictor
    >>> from pyspark.ml import Pipeline
    >>> tsdp = TimeSeriesDataPreparation().
    ...    setDimFieldList(["da", "db"]).
    ...    setMetricFieldList(["metric"]).
    ...    setDateTimeField("date").
    ...    setEncodeSeriesID(False).
    ...    setInputTimeInterval("MONTH").
    ...    setOutTimeInterval("MONTH")
    >>> lcm = LocalContainerManager()
    >>> lcm.exportContainers("k", tsdp.containers())
    >>> expert = TimeSeriesForecastingExpert(lcm).
    ...   setTargetPredictorList([TSCExpertPredictor(targetList = [["da1", "db1", "m1"]])])
    ...   setBuildScoringModelOnly(False).
    ...   setMaxNumLags(4).
    ...   setExpertModelMethod(["Arima","ES","ExhaustiveArima"]).
    ...   setInputContainerKeys(["k"])
    >>> rtsdp = ReverseTimeSeriesDataPreparation(tsdp.manager).
    ...   setInputContainerKeys([tsdp.uid])).
    ...   setDeriveFutureIndicatorField(True)
    >>> pipeline = Pipeline().setStages([tsdp, expert, rtsdp])
    >>> scored = pipeline.fit(data).transform(data)
    >>> scored.show()
    """

    def __init__(self, manager=None):
        super(TimeSeriesForecastingExpert, self).__init__(manager,
                                                          'com.ibm.spss.ml.forecasting.traditional.TimeSeriesForecastingExpert')

    def _create_model(self, java_model):
        return TimeSeriesForecastingModel(None, java_model)


@inherit_doc
class TimeSeriesForecastingExponentialSmoothing(OutputDataCapabilitiesEstimator,
                                                TimeSeriesForecastingExponentialSmoothingParams,
                                                HasESOutlierParams,
                                                HasExportParamsParams,
                                                HasScoreParamsParams,
                                                HasSeasonLengthParams,
                                                HasCILevelParams):

    """
    The exponential smoothing model is a time series model for a univariate time series. "Smoothing" implies predicting a current observation by a weighted average of the past values. "Exponential" implies that the weights are decreased exponentially over time. Thirteen types of exponential smoothing models are provided to handle level, trend, or seasonality in the time series.

    Example code:

    >>> from spss.ml.forecasting.timeseriesdatapreparation import TimeSeriesDataPreparation
    >>> from spss.ml.forecasting.traditional.timeseriesforecasting import TimeSeriesForecastingExponentialSmoothing
    >>> from spss.ml.forecasting.reversetimeseriesdatapreparation import ReverseTimeSeriesDataPreparation
    >>> from spss.ml.forecasting.params.predictor import TSCExpertPredictor
    >>> from pyspark.ml import Pipeline
    >>> tsdp = TimeSeriesDataPreparation().
    ...   setDimFieldList(["da", "db"]).
    ...   setMetricFieldList(["metric"]).
    ...   setDateTimeField("date").
    ...   setEncodeSeriesID(False).
    ...   setInputTimeInterval("MONTH").
    ...   setOutTimeInterval("MONTH")
    >>> lcm = LocalContainerManager()
    >>> lcm.exportContainers("k", tsdp.containers)
    >>> es = TimeSeriesForecastingExponentialSmoothing(lcm).
    ...   setTargetPredictorList([TSCESPredictor(targetList = [["da1", "db1", "m1"]])]).
    ...   setESModelType(ESModelType("none", "none")).
    ...   setBuildScoringModelOnly(False).
    ...   setMaxNumLags(4).
    ...   setForecast(ForecastEs(outForecast = true, forecastSpan = 12, outCI = true)).
    ...   setInputContainerKeys(["k"])
    >>> rtsdp = ReverseTimeSeriesDataPreparation(tsdp.manager).
    ...   setInputContainerKeys([tsdp.uid]).
    ...   setDeriveFutureIndicatorField(True)
    >>> pipeline = Pipeline().setStages([tsdp, es, rtsdp])
    >>> scored = pipeline.fit(data).transform(data)
    >>> scored.show()
    """

    def __init__(self, manager=None):
        super(TimeSeriesForecastingExponentialSmoothing, self).__init__(manager,
                                                                        'com.ibm.spss.ml.forecasting.traditional.TimeSeriesForecastingExponentialSmoothing')

    def _create_model(self, java_model):
        return TimeSeriesForecastingModel(None, java_model)


@inherit_doc
class TimeSeriesForecastingArima(OutputDataCapabilitiesEstimator,
                                 TimeSeriesForecastingArimaParams,
                                 HasExportParamsParams,
                                 HasScoreParamsParams,
                                 HasSeasonLengthParams,
                                 HasCILevelParams
                                 ):
    """
    The Autoregressive Integrated Moving Average (ARIMA) model is a traditional time series model which was first popularized by Box and Jenkins (1976). The model is built for each target time series and can be used to forecast future values. When the model includes other time series as predictor series in addition to the ARIMA part for the target series, it becomes the transfer function (TF) model in which the target series is a function of its own past values, past errors (also called shocks or innovations), and current and past values of the predictor series.

    Example code:

    >>> from spss.ml.forecasting.timeseriesdatapreparation import TimeSeriesDataPreparation
    >>> from spss.ml.forecasting.traditional.timeseriesforecasting import TimeSeriesForecastingArima
    >>> from spss.ml.forecasting.reversetimeseriesdatapreparation import ReverseTimeSeriesDataPreparation
    >>> from spss.ml.forecasting.params.predictor import Predictor
    >>> from pyspark.ml import Pipeline
    >>> tsdp = TimeSeriesDataPreparation().
    ...    setDimFieldList(["da", "db"]).
    ...    setMetricFieldList(["metric"]).
    ...    setDateTimeField("date").
    ...    setEncodeSeriesID(False).
    ...    setInputTimeInterval("MONTH").
    ...    setOutTimeInterval("MONTH")
    >>> lcm = LocalContainerManager()
    >>> lcm.exportContainers("k", tsdp.containers())
    >>> arima = TimeSeriesForecastingArima(lcm).
    ...   setTargetPredictorList([Predictor(targetList = [["da1", "db1", "m1"]])])
    ...   setBuildScoringModelOnly(False).
    ...   setMaxNumLags(4).
    ...   setExpertModelMethod(["Arima","ES","ExhaustiveArima"]).
    ...   setInputContainerKeys(["k"])
    >>> rtsdp = ReverseTimeSeriesDataPreparation(tsdp.manager).
    ...   setInputContainerKeys([tsdp.uid])).
    ...   setDeriveFutureIndicatorField(True)
    >>> pipeline = Pipeline().setStages([tsdp, arima, rtsdp])
    >>> scored = pipeline.fit(data).transform(data)
    >>> scored.show()
    """

    def __init__(self, manager=None):
        super(TimeSeriesForecastingArima, self).__init__(manager,
                                                         'com.ibm.spss.ml.forecasting.traditional.TimeSeriesForecastingArima')

    def _create_model(self, java_model):
        return TimeSeriesForecastingModel(None, java_model)


@inherit_doc
class TimeSeriesForecastingModelReEstimate(OutputDataCapabilitiesEstimator,
                                           TimeSeriesForecastingModelReEstimateParams,
                                           HasESOutlierParams,
                                           HasExportParamsParams,
                                           HasScoreParamsParams,
                                           HasCILevelParams):
    """
    When new time series data arrives, re-estimate will estimate parameters of a time series model,which is built on the old time series data, with new and old time series data.

    Example code:

    >>> from spss.ml.forecasting.traditional.timeseriesforecasting import TimeSeriesForecastingModelReEstimate
    >>> from spss.ml.forecasting.timeseriesdatapreparation import TimeSeriesDataPreparation
    >>> from spss.ml.forecasting.reversetimeseriesdatapreparation import ReverseTimeSeriesDataPreparation
    >>> from spss.ml.forecasting.params.predictor import Predictor
    >>> from pyspark.ml import Pipeline
    >>> tsdp = TimeSeriesDataPreparation().
    ...   setDimFieldList(["da", "db"]).
    ...   setMetricFieldList(["metric"]).
    ...   setDateTimeField("date").
    ...   setEncodeSeriesID(False).
    ...   setInputTimeInterval("MONTH").
    ...   setOutTimeInterval("MONTH")
    >>> lcm = LocalContainerManager()
    >>> lcm.exportContainers("k", tsdp.containers)
    >>> reestimate = TimeSeriesForecastingModelReEstimate(lcm).
    ...   setForecast(ForecastEs(outForecast = True, forecastSpan = 4, outCI = True)).
    ...   setFitSettings(Fit(outFit = True, outCI = True, outResidual = True)).
    ...   setOutInputData(True).
    ...   setInputContainerKeys(["k"])
    >>> rtsdp = ReverseTimeSeriesDataPreparation(tsdp.manager).
    ...   setInputContainerKeys([tsdp.uid]).
    ...   setDeriveFutureIndicatorField(True)
    >>> pipeline = Pipeline().setStages([tsdp, reestimate, rtsdp])
    >>> scored = pipeline.fit(data).transform(data)
    >>> scored.show()
    """
    def __init__(self, manager):
        super(TimeSeriesForecastingModelReEstimate, self).__init__(manager,
                                                                   'com.ibm.spss.ml.forecasting.traditional.TimeSeriesForecastingModelReEstimate')

    def _create_model(self, java_model):
        return TimeSeriesForecastingModel(None, java_model)


@inherit_doc
class TimeSeriesForecastingModel(DirectorScorer, TimeSeriesForecastingModelParams,
                                 HasScoreParamsParams,
                                 HasCILevelParams):
    """
    Model produced by :class:`TimeSeriesForecasting`.

    TimeSeriesForecasting exports two outputs:

    * PMML file, contains model that follows `DMG PMML Standard <http://dmg.org/pmml/v4-2-1/TimeSeriesModel.html>`_.

    * StatXML file, contains extended model information.

    More details about outputs, please refer to `TimeSeriesForecasting Output Document <../../../../../../output-doc/TimeSeriesForecasting.html>`_.
    """

    def __init__(self, manager, java_model=None):
        super(TimeSeriesForecastingModel, self).__init__(manager,
                                                         'com.ibm.spss.ml.forecasting.traditional.TimeSeriesForecastingModel',
                                                         java_model)
