#
# IBM Confidential
#
# OCO Source Materials
#
# NextGen Workbench
#
# (c) Copyright IBM Corp. 2016
#
# The source code for this program is not published or otherwise
# divested of its trade secrets, irrespective of what has been
# deposited with the U.S. Copyright Office.
#

from pyspark.mllib.common import inherit_doc

from spss.ml.common.wrapper import ContainerCapability, AFEstimator,IdentityScorer
from spss.ml.param.timeseriesexploration import TimeSeriesExplorationParams


@inherit_doc
class TimeSeriesExploration(AFEstimator, ContainerCapability, TimeSeriesExplorationParams):
    """
    Time Series Exploration explores the characteristics of time series data based on some statistics and tests to generate preliminary insights about the time series before modeling. It covers not only analytic methods for expert users(including time series clustering, unit root test, and correlations) but also provides an automatic exploration process based on a simple time series decomposition method for business users.

    Example code:

    >>> from spss.ml.common.wrapper import LocalContainerManager
    >>> from spss.ml.forecasting.timeseriesexploration import TimeSeriesExploration
    >>> tse = TimeSeriesExploration(lcm).
    ...   setInputContainerKeys(["Container"]).
    ...   setAutoExploration(True).
    ...   setClustering(True)
    >>> tseModel = tse.fit(df)
    >>> predictions = tseModel.transform(data)
    >>> predictions.show()
    """

    def __init__(self, manager=None):
        super(TimeSeriesExploration, self).__init__(manager,'com.ibm.spss.ml.forecasting.TimeSeriesExploration')

    def _create_model(self, java_model):
        return TimeSeriesExplorationModel(None, java_model)


@inherit_doc
class TimeSeriesExplorationModel(IdentityScorer, TimeSeriesExplorationParams):
    """
    Model produced by :class:`TimeSeriesExploration`.

    TimeSeriesExploration exports two outputs:

    * JSON file, contains model information.
    * XML file, contains model information.

    More details about outputs, please refer to
    `TimeSeriesExploration Output Document <../../../../../output-doc/TimeSeriesExploration.html>`_.
    """

    def __init__(self, manager, java_model=None):
        super(TimeSeriesExplorationModel, self).__init__(manager, 'com.ibm.spss.ml.forecasting.TimeSeriesExplorationModel', java_model)
