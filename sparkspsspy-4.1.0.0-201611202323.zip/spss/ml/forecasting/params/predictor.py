#
# IBM Confidential
#
# OCO Source Materials
#
# NextGen Workbench
#
# (c) Copyright IBM Corp. 2016
#
# The source code for this program is not published or otherwise
# divested of its trade secrets, irrespective of what has been
# deposited with the U.S. Copyright Office.
#
from pyspark.mllib.common import inherit_doc

from spss.ml.common.wrapper import SPSSJavaWrapper


@inherit_doc
class TSCExpertPredictor(object):
    def __init__(self,
                 targetList,
                 targetExcludeList=None,
                 predictorEventList=None,
                 predictorSeriesList=None,
                 predictorForceList=None,
                 predictorExcludeList=None):
        self._targetList = SPSSJavaWrapper.scalaListList(targetList)
        self._targetExcludeList = SPSSJavaWrapper.scalaOptionListList(targetExcludeList)
        self._predictorEventList = SPSSJavaWrapper.scalaOptionListList(predictorEventList)
        self._predictorSeriesList = SPSSJavaWrapper.scalaOptionListList(predictorSeriesList)
        self._predictorForceList = SPSSJavaWrapper.scalaOptionListList(predictorForceList)
        self._predictorExcludeList = SPSSJavaWrapper.scalaOptionListList(predictorExcludeList)

        self._java_object = self.value

    @property
    def value(self):
        return SPSSJavaWrapper._new_java_obj('com.ibm.spss.ml.forecasting.params.TSCExpertPredictor',
                                             self._targetList,
                                             self._targetExcludeList,
                                             self._predictorEventList,
                                             self._predictorSeriesList,
                                             self._predictorForceList,
                                             self._predictorExcludeList)


@inherit_doc
class TSCESPredictor(object):
    def __init__(self,
                 targetList,
                 targetExcludeList=None,
                 trendType="none",
                 seasonType="none"):
        self._targetList = SPSSJavaWrapper.scalaListList(targetList)
        self._targetExcludeList = SPSSJavaWrapper.scalaOptionListList(targetExcludeList)

        self._trendType = trendType
        self._seasonType = seasonType

        self._java_object = self.value

    @property
    def value(self):
        return SPSSJavaWrapper._new_java_obj('com.ibm.spss.ml.forecasting.params.TSCESPredictor',
                                             self._targetList,
                                             self._targetExcludeList,
                                             self._trendType,
                                             self._seasonType)


@inherit_doc
class Predictor(object):
    def __init__(self,
                 targetList,
                 targetExcludeList=None,
                 predictorIncludeList=None,
                 predictorCandidateList=None,
                 predictorExcludeList=None):
        self._targetList = SPSSJavaWrapper.scalaListList(targetList)
        self._targetExcludeList = SPSSJavaWrapper.scalaOptionListList(targetExcludeList)
        self._predictorIncludeList = SPSSJavaWrapper.scalaOptionListList(predictorIncludeList)
        self._predictorCandidateList = SPSSJavaWrapper.scalaOptionListList(predictorCandidateList)
        self._predictorExcludeList = SPSSJavaWrapper.scalaOptionListList(predictorExcludeList)

        self._java_object = self.value

    @property
    def value(self):
        return SPSSJavaWrapper._new_java_obj('com.ibm.spss.ml.forecasting.params.Predictor',
                                             self._targetList,
                                             self._targetExcludeList,
                                             self._predictorIncludeList,
                                             self._predictorCandidateList,
                                             self._predictorExcludeList)


@inherit_doc
class MaxNumberOfPredictor(object):
    def __init__(self, usedefault, value=20):
        self._useDefault = usedefault
        self._value = value
        self._java_object = self.value

    @property
    def value(self):
        return SPSSJavaWrapper._new_java_obj('com.ibm.spss.ml.forecasting.params.MaxNumberOfPredictor',
                                             self._useDefault,
                                             self._value)


@inherit_doc
class MaxLag(object):
    def __init__(self, source, value=5):
        self._source = source
        self._value = value

    @property
    def value(self):
        return SPSSJavaWrapper._new_java_obj('com.ibm.spss.ml.forecasting.params.MaxLag',
                                             self._source,
                                             self._value)


@inherit_doc
class ESModelType(object):
    def __init__(self, trendType="none", seasonType="none", secondSeasonType="none"):
        self._trendType = trendType
        self._seasonType = seasonType
        self._secondSeasonType = secondSeasonType
        self._java_object = self.value

    @property
    def value(self):
        return SPSSJavaWrapper._new_java_obj('com.ibm.spss.ml.forecasting.params.ESModelType',
                                             self._trendType,
                                             self._seasonType,
                                             self._secondSeasonType)


@inherit_doc
class ScorePredictor(object):
    def __init__(self, targetIncludedList=None, targetExcludedList=None,targetModelIncludedList=None ):
        t_in_list = SPSSJavaWrapper.scalaNil()
        if targetIncludedList is not None:
            elem_list = []
            for elem in targetIncludedList:
                elem_list.append(SPSSJavaWrapper.scalaList(elem))
            t_in_list = SPSSJavaWrapper.scalaList(elem_list)
        t_ex_list = SPSSJavaWrapper.scalaNil()
        if targetExcludedList is not None:
            elem_list = []
            for elem in targetExcludedList:
                elem_list.append(SPSSJavaWrapper.scalaList(elem))
            t_ex_list = SPSSJavaWrapper.scalaList(elem_list)

        t_model_in_list = SPSSJavaWrapper.scalaNil()
        if targetModelIncludedList is not None:
            elem_list = []
            for elem in targetModelIncludedList:
                elem_elem_list = []
                for elem_elem in elem:
                    elem_elem_list.append(SPSSJavaWrapper.scalaList(elem_elem))
                elem_list.append(SPSSJavaWrapper.scalaList(elem_elem_list))
            t_model_in_list = SPSSJavaWrapper.scalaList(elem_list)
        self._targetIncludedList = SPSSJavaWrapper.scalaSome(t_in_list)
        self._targetExcludedList = SPSSJavaWrapper.scalaSome(t_ex_list)
        self._targetModelIncludedList = SPSSJavaWrapper.scalaSome(t_model_in_list)
        self._java_object = self.value()

    def value(self):
        return SPSSJavaWrapper._new_java_obj("com.ibm.spss.ml.forecasting.params.ScorePredictor", self._targetIncludedList,
                                             self._targetExcludedList, self._targetModelIncludedList)
